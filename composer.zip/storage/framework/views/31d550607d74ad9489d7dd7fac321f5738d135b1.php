<!DOCTYPE html>
<html lang="en">
<head>
    <title>LaraTask</title>

    <!-- CSS And JavaScript -->
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
</head>

<body>
<div class="container">
    <nav class="navbar navbar-default">
        <!-- Navbar Contents -->
    </nav>
</div>

<?php echo $__env->yieldContent('content'); ?>
</body>
</html>