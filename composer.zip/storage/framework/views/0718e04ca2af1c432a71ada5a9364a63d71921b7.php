<?php $__env->startSection('content'); ?>

        <!-- Bootstrap Boilerplate... -->
<div class="container">
<div class="panel-body">
    <!-- Display Validation Errors -->
    <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- New Task Form -->
    <form action="/task" method="POST" class="form-horizontal">
        <?php echo e(csrf_field()); ?>


                <!-- Task Name -->
        <div class="form-group">
            <label for="task" class="col-sm-3 control-label">Task</label>

            <div class="col-sm-6">
                <input type="text" name="name" id="task-name" class="form-control">
            </div>
        </div>
        <div class="form-group">
            <label for="assigned_to" class="col-sm-3 control-label">Assigned To</label>

            <div class="col-sm-6">
                <input type="text" name="assigned_to" id="assigned_to" class="form-control">
            </div>
        </div>
        <div class="form-group">
            <label for="assigned_by" class="col-sm-3 control-label">Assigned By</label>

            <div class="col-sm-6">
                <input type="text" name="assigned_by" id="assigned_by" class="form-control">
            </div>
        </div>
        <div class="form-group">
            <label for="tags" class="col-sm-3 control-label">Tags</label>

            <div class="col-sm-6">
                <input type="text" name="tags" id="tags" class="form-control">
            </div>
        </div>

        <!-- Add Task Button -->
        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-6">
                <button type="submit" class="btn btn-default">
                    <i class="fa fa-plus"></i> Add Task
                </button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
<div class="container"><!-- Current Tasks -->
<?php if(count($tasks) > 0): ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            Current Tasks
        </div>

        <div class="panel-body">
            <table class="table table-striped task-table">
                <thead>
                <th>Task</th>
                <th>Assigned By</th>
                <th>Assigned To</th>
                <th>Tags</th>
                <th>Created</th>
                <th>&nbsp;</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="table-text"><div><?php echo e($task->name); ?></div></td>
                        <td class="table-text"><div><?php echo e($task->assigned_by); ?></div></td>
                        <td class="table-text"><div><?php echo e($task->assigned_to); ?></div></td>
                        <td class="table-text"><div><?php echo e($task->tags); ?></div></td>

                        <!-- Task Delete Button -->
                        <td>
                            <form action="<?php echo e(url('task/'.$task->id)); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>


                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-btn fa-trash"></i>Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>